/*************************************************************************

   Program:    
   File:       angle.c
   
   Version:    V1.5R
   Date:       27.03.95
   Function:   Calculate angles, torsions, etc.
   
   Copyright:  (c) SciTech Software 1993-5
   Author:     Dr. Andrew C. R. Martin
   Address:    SciTech Software
               23, Stag Leys,
               Ashtead,
               Surrey,
               KT21 2TD.
   Phone:      +44 (0) 1372 275775
   EMail:      martin@biochem.ucl.ac.uk
               
**************************************************************************

   This program is not in the public domain, but it may be copied
   according to the conditions laid out in the accompanying file
   COPYING.DOC

   The code may not be sold commercially or included as part of a 
   commercial product except as described in the file COPYING.DOC.

**************************************************************************

   Description:
   ============
   These routines return angles and torsion angles. The definition of a
   torsion angle is the chemical definition:
   i.e. Assuming the atoms are co-planar:
            A---B          A---B
                | = 0.0        |  = 180.0
                |              |
            D---C              C---D

**************************************************************************

   Usage:
   ======
   REAL angle(xi,yi,zi,xj,yj,zj,xk,yk,zk)
   Input:   REAL     xi,yi,zi    Input coordinates
                     xj,yj,zj
                     xk,yk,zk
   Returns: REAL                 The angle between the 3 atoms


   REAL phi(xi,yi,zi,xj,yj,zj,xk,yk,zk,xl,yl,zl)
   Input:   REAL     xi,yi,zi    Input coordinates
                     xj,yj,zj
                     xk,yk,zk
                     xl,yl,zl
   Returns: REAL                 The torsion angle between the 4 atoms


   REAL simpleang(ang)
   Input:   REAL     ang         An angle
   Returns: REAL                 Simplified angle
   
   Simplifies a signed angle to an unsigned angle <=2*PI


   REAL TrueAngle(REAL opp, REAL adj)
   Input:   REAL     opp         Length of opposite side
            REAL     adj         Length of adjacent side
   Returns: REAL                 The angle from 0 to 2PI

   Returns the true positive angle between 0 and 2PI given the opp and
   adj lengths

**************************************************************************

   Revision History:
   =================
   V1.0  07.02.91 Original
   V1.1  17.02.91 Corrected comments to new standard and added phi()
   V1.2  04.03.91 angle() and phi() now return _correct_ values!
   V1.3  01.06.92 ANSIed
   V1.4  08.12.92 Changed abs() to ABS() from macros.h
   V1.5  27.03.95 Added TrueAngle()

*************************************************************************/
/* Includes
*/
#include <math.h>

#include "MathType.h"
#include "macros.h"

/************************************************************************/
/* Defines and macros
*/

/************************************************************************/
/* Globals
*/

/************************************************************************/
/* Prototypes
*/

/************************************************************************/
/*>REAL angle(REAL xi,REAL yi,REAL zi,REAL xj,REAL yj,
              REAL zj,REAL xk,REAL yk,REAL zk)
   ---------------------------------------------------
   Input:   REAL    xi,yi,zi    Input coordinates
                    xj,yj,zj
                    xk,yk,zk
   Returns: REAL                The angle between the 3 atoms

   Calculates the angle between three sets of coordinates

   07.02.89 Original    By: ACRM
   04.03.91 Fixed return value
   16.06.93 Changed float to REAL
*/
REAL angle(REAL xi,
           REAL yi,
           REAL zi,
           REAL xj,
           REAL yj,
           REAL zj,
           REAL xk,
           REAL yk,
           REAL zk)
{
   REAL qx,qy,qz,sq,px,py,pz,sp,cosa2,a2;

   px = xi - xj;
   py = yi - yj;
   pz = zi - zj;
   sp = sqrt(px * px + py * py + pz * pz);

   qx = xk - xj;
   qy = yk - yj;
   qz = zk - zj;
   sq = sqrt(qx * qx + qy * qy + qz * qz);

   cosa2 = (qx * px + qy * py + qz * pz) / (sp * sq);
   a2 = acos(cosa2);

   return(a2);
}

/************************************************************************/
/*>REAL phi(REAL xi,REAL yi,REAL zi,REAL xj,REAL yj,REAL zj,
            REAL xk,REAL yk,REAL zk,REAL xl,REAL yl,REAL zl)
   ---------------------------------------------------------
   Input:   REAL    xi,yi,zi    Input coordinates
                    xj,yj,zj
                    xk,yk,zk
                    xl,yl,zl
   Returns: REAL                The torsion angle between the 4 atoms

   Calculates the torsion angle described by 4 sets of coordinates.

   04.03.91 Original    By: ACRM
   16.06.93 Changed float to REAL
*/
REAL phi(REAL xi,
         REAL yi,
         REAL zi,
         REAL xj,
         REAL yj,
         REAL zj,
         REAL xk,
         REAL yk,
         REAL zk,
         REAL xl,
         REAL yl,
         REAL zl)
{
   REAL xij,yij,zij,
        xkj,ykj,zkj,
        xkl,ykl,zkl,
        dxi,dyi,dzi,
        gxi,gyi,gzi,
        bi,bk,ct,
        boi2,boj2,
        z1,z2,ap,s,
        bioj,bjoi;


   /* Calculate the vectors C,B,C                                       */
   xij = xi - xj;
   yij = yi - yj;
   zij = zi - zj;
   xkj = xk - xj;
   ykj = yk - yj;
   zkj = zk - zj;
   xkl = xk - xl;
   ykl = yk - yl;
   zkl = zk - zl;

   /* Calculate the normals to the two planes n1 and n2
      this is given as the cross products:
       AB x BC
      --------- = n1
      |AB x BC|

       BC x CD
      --------- = n2
      |BC x CD|
   */
   dxi = yij * zkj - zij * ykj;     /* Normal to plane 1                */
   dyi = zij * xkj - xij * zkj;
   dzi = xij * ykj - yij * xkj;
   gxi = zkj * ykl - ykj * zkl;     /* Mormal to plane 2                */
   gyi = xkj * zkl - zkj * xkl;
   gzi = ykj * xkl - xkj * ykl;

   /* Calculate the length of the two normals                           */
   bi = dxi * dxi + dyi * dyi + dzi * dzi;
   bk = gxi * gxi + gyi * gyi + gzi * gzi;
   ct = dxi * gxi + dyi * gyi + dzi * gzi;

   boi2 = 1./bi;
   boj2 = 1./bk;
   bi   = (REAL)sqrt((double)bi);
   bk   = (REAL)sqrt((double)bk);

   z1   = 1./bi;
   z2   = 1./bk;
   bioj = bi * z2;
   bjoi = bk * z1;
   ct   = ct * z1 * z2;
   if (ct >  1.0)   ct = 1.0;
   if (ct < (-1.0)) ct = -1.0;
   ap   = acos(ct);

   s = xkj * (dzi * gyi - dyi * gzi)
     + ykj * (dxi * gzi - dzi * gxi)
     + zkj * (dyi * gxi - dxi * gyi);

   if (s < 0.0) ap = -ap;

   ap = (ap > 0.0) ? PI-ap : -(PI+ap);

   return(ap);
}

/************************************************************************/
/*>REAL simpleangle(REAL ang)
   --------------------------
   Input:   REAL    ang         An angle
   Returns: REAL                Simplified angle
   
   Simplifies a signed angle to an unsigned angle <=2*PI

   07.02.89 Original    By: ACRM
   04.03.91 Fixed return value
   16.06.93 Changed float to REAL
*/
REAL simpleangle(REAL ang)
{
   /* Reduce to less than 360 degrees                                   */
   while(ang > 2*PI) ang -= 2*PI;
   
   if(ang >= 0.0 && ang <= PI)         /* 1st & 2nd quadrant +ve        */
      return(ang);
   else if(ang > PI)                   /* 3rd & 4th quadrant +ve        */
      ang = 2*PI - ang;
   else if(ang < 0.0 && ang > -PI)     /* 1st & 2nd quadrant -ve        */
      ang = ABS(ang);
   else                                /* 3rd & 4th quadrant -ve        */
      ang = 2*PI + ang;
   
   return(ang);
}

/************************************************************************/
/*>REAL TrueAngle(REAL opp, REAL adj)
   ----------------------------------
   Input:   REAL     opp     Opposite length
            REAL     adj     Adjacent length
   Returns: REAL             Angle between 0 and 2PI

   Return the +ve angle between 0 and 2PI given the opp and adj values.

   25.07.94 Original    By: ACRM
*/
REAL TrueAngle(REAL opp, REAL adj)
{
   REAL ang;
   
   if(adj != 0.0)
   {
      ang = (REAL)atan((double)(opp/adj));

      /* 4th quadrant; ang -ve so add 2PI                             */
      if(opp < 0.0 && adj > 0.0) ang += 2*PI;

      /* 2nd & 3rd quadrant; add PI                                     */
      if(adj < 0.0) ang += PI;
   }
   else
   {
      if(opp>0.0)                /* 1st->2nd quadrant boundary          */
         ang = PI/2.0;
      else                       /* 3rd->4th quadrant boundary          */
         ang = 3.0*PI/2.0;
   }
   
   if(opp == 0.0)
   {
      if(adj > 0.0)              /* 4th->1st quadrant boundary          */
         ang = 0.0;
      else                       /* 2nd->3rd quadrant boundary          */
         ang = PI;
   }

   return(ang);
}

